@echo off
echo ==========================================
echo Instalador del Agente de CraftControl
echo ==========================================
echo.
echo Instalando dependencias (esto puede tardar unos segundos)...
call npm install
echo.
echo Dependencias instaladas correctamente.
echo.
echo IMPORTANTE:
echo Para encender tu agente, abre una terminal en esta carpeta y pega
echo el comando que te dio la pagina web (node index.js --url... --token...)
echo.
pause
